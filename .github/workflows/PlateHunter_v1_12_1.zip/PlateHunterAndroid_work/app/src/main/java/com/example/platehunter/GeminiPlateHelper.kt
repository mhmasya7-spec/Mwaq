package com.example.platehunter

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

object GeminiPlateHelper {
    /** Call from a worker thread. Gemini is only a fallback when local extraction fails. */
    fun extractPlate(apiKey: String, transcript: String): String? {
        if (apiKey.isBlank() || transcript.isBlank()) return null
        var conn: HttpURLConnection? = null
        return try {
            val url = URL("https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=${java.net.URLEncoder.encode(apiKey, "UTF-8")}")
            conn = (url.openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"; connectTimeout = 12000; readTimeout = 12000; doOutput = true
                setRequestProperty("Content-Type", "application/json; charset=utf-8")
            }
            val prompt = "استخرج لوحة سيارة سعودية واحدة فقط من النص التالي. اللوحة 3 حروف عربية ثم 4 أرقام. اكتب الحروف متصلة ثم الأرقام دون مسافات، مثال سرط7520. إذا كانت الأرقام 3 فقط أضف صفرًا في البداية. لا تخمن؛ أعد NONE إن لم تكن واضحة. النص: $transcript"
            val body = JSONObject().put("contents", JSONArray().put(JSONObject().put("parts", JSONArray().put(JSONObject().put("text", prompt))))).toString()
            conn.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            if (conn.responseCode !in 200..299) return null
            val raw = conn.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
            val text = JSONObject(raw).optJSONArray("candidates")?.optJSONObject(0)?.optJSONObject("content")
                ?.optJSONArray("parts")?.optJSONObject(0)?.optString("text")?.trim().orEmpty()
            PlateParser.normalize(text).takeIf { it.isNotBlank() }
        } catch (_: Exception) { null } finally { conn?.disconnect() }
    }
}
